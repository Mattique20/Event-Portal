﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace SE
{
    public partial class StudentEvent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindEvents();
            }
        }

        private void BindEvents()
        {
            string connectionString = "Data Source=SHAHEER\\SQLEXPRESS01;Initial Catalog=SE_Project;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT title, description, date, time, venue, Department, category FROM Event";
                SqlCommand command = new SqlCommand(query, connection);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    string title = reader["title"].ToString();
                    string description = reader["description"].ToString();
                    DateTime date = Convert.ToDateTime(reader["date"]);
                    TimeSpan time = TimeSpan.Parse(reader["time"].ToString());
                    string venue = reader["venue"].ToString();
                    string department = reader["Department"].ToString();
                    string category = reader["category"].ToString();

                    // Create a card for the event and add it to the eventContainer div
                    AddEventCard(title, description, date, time, venue, department, category);
                }

                reader.Close();
            }
        }

        private void AddEventCard(string title, string description, DateTime date, TimeSpan time, string venue, string department, string category)
        {
            // Create a card element
            Panel card = new Panel();
            card.CssClass = "card";
            card.Attributes.Add("data-department", department);

            // Populate card content
            Literal content = new Literal();
            content.Text = "<h3>" + title + "</h3>" +
                           "<p>" + description + "</p>" +
                           "<p>Date: " + date.ToString("yyyy-MM-dd") + "</p>" +
                           "<p>Time: " + time.ToString(@"hh\:mm") + "</p>" +
                           "<p>Venue: " + venue + "</p>" +
                           "<p>Department: " + department + "</p>" +
                           "<p>Category: " + category + "</p>";

            card.Controls.Add(content);


            // Add the card to the eventContainer div
            eventContainer.Controls.Add(card);
        }

        
    }
}
